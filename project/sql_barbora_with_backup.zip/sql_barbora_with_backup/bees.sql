-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bees
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `games`
--

DROP TABLE IF EXISTS `games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `games` (
  `game_id` varchar(50) NOT NULL,
  `game_date` date DEFAULT NULL,
  `fk_bees` varchar(50) DEFAULT NULL,
  `fk_team2` varchar(50) DEFAULT NULL,
  `bees_shots` int DEFAULT NULL,
  `team2_shots` int DEFAULT NULL,
  `bees_goals` int DEFAULT NULL,
  `team2_goals` int DEFAULT NULL,
  `bees_penalties` int DEFAULT NULL,
  `team2_penalties` int DEFAULT NULL,
  `home_away` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`game_id`),
  KEY `fk_bees` (`fk_bees`),
  KEY `fk_team2` (`fk_team2`),
  CONSTRAINT `games_ibfk_1` FOREIGN KEY (`fk_bees`) REFERENCES `teams` (`team_id`),
  CONSTRAINT `games_ibfk_2` FOREIGN KEY (`fk_team2`) REFERENCES `teams` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `games`
--

LOCK TABLES `games` WRITE;
/*!40000 ALTER TABLE `games` DISABLE KEYS */;
INSERT INTO `games` VALUES ('g1','2019-09-21','t2','t6',26,20,5,4,8,16,'home\r'),('g10','2019-10-26','t2','t10',31,33,4,3,12,12,'home\r'),('g11','2019-10-27','t2','t7',28,26,2,3,4,26,'home\r'),('g12','2019-11-02','t2','t6',39,32,2,3,10,12,'home\r'),('g13','2019-11-03','t2','t7',35,26,5,6,50,20,'away\r'),('g14','2019-11-09','t2','t5',28,34,2,7,8,10,'away\r'),('g15','2019-11-10','t2','t1',23,27,2,3,24,8,'home\r'),('g16','2019-11-17','t2','t3',38,41,7,6,26,6,'home\r'),('g17','2019-11-23','t2','t1',34,29,5,3,90,86,'away\r'),('g18','2019-11-24','t2','t9',38,27,2,4,22,28,'home\r'),('g19','2019-11-30','t2','t6',28,33,6,2,12,8,'away\r'),('g2','2019-09-22','t2','t6',23,38,0,3,40,22,'away\r'),('g3','2019-09-28','t2','t1',15,33,2,4,8,10,'away\r'),('g4','2019-09-29','t2','t4',32,27,4,3,33,43,'home\r'),('g5','2019-10-05','t2','t9',30,40,0,5,12,12,'away\r'),('g6','2019-10-06','t2','t5',27,25,4,3,57,16,'home\r'),('g7','2019-10-13','t2','t9',19,34,1,2,10,8,'home\r'),('g8','2019-10-19','t2','t5',52,30,4,3,44,86,'away\r'),('g9','2019-10-20','t2','t1',34,36,2,9,26,12,'home\r');
/*!40000 ALTER TABLE `games` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goals`
--

DROP TABLE IF EXISTS `goals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goals` (
  `goal_id` varchar(50) NOT NULL,
  `fk_goal_gameid` varchar(50) NOT NULL,
  `fk_goal_player` varchar(50) NOT NULL,
  `fk_goal_assist_player1` varchar(50) DEFAULT NULL,
  `fk_goal_assist_player2` varchar(50) DEFAULT NULL,
  `goal_time` time DEFAULT NULL,
  PRIMARY KEY (`goal_id`),
  KEY `fk_goal_gameid` (`fk_goal_gameid`),
  KEY `fk_goal_player` (`fk_goal_player`),
  KEY `fk_goal_assist_player1` (`fk_goal_assist_player1`),
  KEY `fk_goal_assist_player2` (`fk_goal_assist_player2`),
  CONSTRAINT `goals_ibfk_1` FOREIGN KEY (`fk_goal_gameid`) REFERENCES `games` (`game_id`),
  CONSTRAINT `goals_ibfk_2` FOREIGN KEY (`fk_goal_player`) REFERENCES `players` (`player_id`),
  CONSTRAINT `goals_ibfk_3` FOREIGN KEY (`fk_goal_assist_player1`) REFERENCES `players` (`player_id`),
  CONSTRAINT `goals_ibfk_4` FOREIGN KEY (`fk_goal_assist_player2`) REFERENCES `players` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goals`
--

LOCK TABLES `goals` WRITE;
/*!40000 ALTER TABLE `goals` DISABLE KEYS */;
INSERT INTO `goals` VALUES ('goal1','g1','p20','p9','p18','00:19:32'),('goal10','g4','p22','p7','p8','00:34:23'),('goal11','g4','p19','p13','p15','00:37:20'),('goal12','g6','p21','p18','p20','00:38:42'),('goal13','g6','p8','p6',NULL,'00:49:35'),('goal14','g6','p8','p2',NULL,'00:52:13'),('goal15','g6','p23',NULL,NULL,'01:05:00'),('goal16','g7','p18','p13','p6','00:58:05'),('goal17','g8','p17','p6',NULL,'00:29:08'),('goal18','g8','p18','p22','p13','00:52:07'),('goal19','g8','p18','p22','p20','00:59:35'),('goal2','g1','p20','p14',NULL,'00:31:21'),('goal20','g8','p2','p17',NULL,'00:59:54'),('goal21','g9','p9','p13','p20','00:25:18'),('goal22','g9','p9','p22',NULL,'00:51:07'),('goal23','g10','p14','p6','p17','00:04:33'),('goal24','g10','p22','p13','p11','00:08:56'),('goal25','g10','p18','p13',NULL,'00:53:17'),('goal26','g10','p6','p18','p9','01:03:26'),('goal27','g11','p19','p3','p18','00:13:45'),('goal28','g11','p19','p3','p14','00:26:17'),('goal29','g12','p2','p16','p17','00:28:25'),('goal3','g1','p9','p7',NULL,'00:42:13'),('goal30','g12','p17','p11','p6','00:51:48'),('goal31','g13','p17','p8',NULL,'00:07:37'),('goal32','g13','p9','p10',NULL,'00:09:22'),('goal33','g13','p3','p9','p20','00:46:24'),('goal34','g13','p18','p22','p20','00:51:24'),('goal35','g13','p9','p17',NULL,'00:53:09'),('goal36','g14','p17','p22',NULL,'00:04:54'),('goal37','g14','p3','p14','p2','00:58:22'),('goal38','g15','p3','p8','p17','00:26:38'),('goal39','g15','p18',NULL,NULL,'00:46:09'),('goal4','g1','p9','p14',NULL,'00:51:15'),('goal40','g16','p10','p19','p14','00:11:09'),('goal41','g16','p6','p14','p19','00:24:34'),('goal42','g16','p8','p19','p14','00:29:58'),('goal43','g16','p10','p14','p8','00:37:34'),('goal44','g16','p22','p12','p18','00:38:32'),('goal45','g16','p20','p18','p14','00:59:52'),('goal46','g16','p23',NULL,NULL,'01:05:00'),('goal47','g17','p5','p21','p11','00:07:40'),('goal48','g17','p14','p18','p3','00:11:26'),('goal49','g17','p10','p8',NULL,'00:12:57'),('goal5','g1','p22','p6','p13','00:55:47'),('goal50','g17','p22','p5','p20','00:22:35'),('goal51','g17','p18','p20','p3','00:49:04'),('goal52','g18','p20','p5',NULL,'00:29:44'),('goal53','g18','p5','p6','p22','00:33:08'),('goal54','g19','p12','p5','p6','00:07:46'),('goal55','g19','p8','p18','p12','00:15:45'),('goal56','g19','p22','p5',NULL,'00:29:41'),('goal57','g19','p18','p6','p8','00:37:51'),('goal58','g19','p5','p12','p22','00:55:42'),('goal59','g19','p5','p22','p6','00:57:47'),('goal6','g3','p18','p13',NULL,'00:28:18'),('goal7','g3','p18','p6','p14','00:31:19'),('goal8','g4','p18','p3','p12','00:04:16'),('goal9','g4','p12','p20','p15','00:07:46');
/*!40000 ALTER TABLE `goals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `penalties`
--

DROP TABLE IF EXISTS `penalties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `penalties` (
  `penalty_id` varchar(50) NOT NULL,
  `fk_penalty_game` varchar(50) DEFAULT NULL,
  `fk_penalty_player` varchar(50) DEFAULT NULL,
  `length` int DEFAULT NULL,
  `penalty_type` varchar(50) DEFAULT NULL,
  `penalty_time` time DEFAULT NULL,
  `goal_scored` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`penalty_id`),
  KEY `fk_penalty_game` (`fk_penalty_game`),
  KEY `fk_penalty_player` (`fk_penalty_player`),
  CONSTRAINT `penalties_ibfk_1` FOREIGN KEY (`fk_penalty_game`) REFERENCES `games` (`game_id`),
  CONSTRAINT `penalties_ibfk_2` FOREIGN KEY (`fk_penalty_player`) REFERENCES `players` (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `penalties`
--

LOCK TABLES `penalties` WRITE;
/*!40000 ALTER TABLE `penalties` DISABLE KEYS */;
INSERT INTO `penalties` VALUES ('pen1','g1','p15',2,'TRIP','00:01:12','yes\r'),('pen10','g2','p18',2,'BOARD','00:53:35','no\r'),('pen100','g15','p2',2,'BOARD','00:17:52','no\r'),('pen101','g15','p2',10,'BOARD','00:17:52','no\r'),('pen102','g15','p11',2,'CROSS','00:30:24','yes\r'),('pen103','g15','p18',2,'ELBOW','00:30:45','no\r'),('pen104','g15','p3',2,'SLASH','00:36:34','no\r'),('pen105','g15','p10',2,'MISC','00:45:28','no\r'),('pen106','g16','p23',2,'TOO-M','00:04:10','no\r'),('pen107','g16','p6',10,'IL-EQ','00:30:46','yes\r'),('pen108','g16','p2',2,'CHE-H','00:33:07','no\r'),('pen109','g16','p2',10,'CHE-H','00:33:07','yes\r'),('pen11','g2','p18',10,'BOARD','00:53:35','yes\r'),('pen110','g16','p10',2,'TRIP','00:41:49','no\r'),('pen111','g17','p10',2,'CROSS','00:15:32','no\r'),('pen112','g17','p8',2,'FIGHT','00:18:34','no\r'),('pen113','g17','p8',2,'FIGHT','00:18:34','no\r'),('pen114','g17','p5',2,'HI-ST','00:19:09','yes\r'),('pen115','g17','p3',2,'HOOK','00:24:45','yes\r'),('pen116','g17','p11',2,'SLASH','00:25:35','no\r'),('pen117','g17','p10',2,'HOLD','00:32:15','yes\r'),('pen118','g17','p3',2,'ROUGH','00:49:22','no\r'),('pen119','g17','p22',5,'FIGHT','01:00:00','no\r'),('pen12','g2','p2',2,'SLASH','00:54:15','no\r'),('pen120','g17','p22',20,'GA-MI','01:00:00','no\r'),('pen121','g17','p14',5,'FIGHT','01:00:00','no\r'),('pen122','g17','p14',20,'GA-MI','01:00:00','no\r'),('pen123','g17','p10',20,'GA-MI','01:00:00','no\r'),('pen124','g17','p10',2,'L-PLB','01:00:00','no\r'),('pen125','g17','p10',2,'L-PLB','01:00:00','no\r'),('pen126','g18','p5',2,'TRIP','00:07:39','no\r'),('pen127','g18','p11',2,'L-HIT','00:19:31','no\r'),('pen128','g18','p5',2,'HOOK','00:35:58','no\r'),('pen129','g18','p10',2,'HOOK','00:53:05','no\r'),('pen13','g2','p14',2,'ROUGH','00:54:15','no\r'),('pen130','g18','p14',2,'G-INTRF','00:59:48','no\r'),('pen131','g18','p22',2,'CHE-H','01:00:00','no\r'),('pen132','g18','p22',10,'MISC','01:00:00','no\r'),('pen133','g19','p11',2,'SLASH','00:10:41','no\r'),('pen134','g19','p11',2,'SLASH','00:20:00','no\r'),('pen135','g19','p2',2,'HOOK','00:24:55','no\r'),('pen136','g19','p10',2,'TRIP','00:35:19','no\r'),('pen137','g19','p22',2,'ROUGH','00:36:17','no\r'),('pen138','g19','p1',2,'TRIP','00:36:55','no\r'),('pen14','g2','p23',2,'TOO-M','00:57:47','no\r'),('pen15','g2','p1',2,'SLASH','00:59:33','no\r'),('pen16','g2','p2',2,'CHE-H','00:59:49','no\r'),('pen17','g2','p2',10,'CHE-H','00:59:49','no\r'),('pen18','g3','p11',2,'CROSS','00:12:12','no\r'),('pen19','g3','p22',2,'L-HIT','00:16:05','yes\r'),('pen2','g1','p3',0,'HOOK','00:13:36','yes\r'),('pen20','g3','p22',2,'DELAY','00:46:35','no\r'),('pen21','g3','p22',2,'TRIP','00:56:59','no\r'),('pen22','g4','p11',2,'SLASH','00:22:12','no\r'),('pen23','g4','p20',2,'TRIP','00:41:46','no\r'),('pen24','g4','p22',2,'HOOK','00:49:03','no\r'),('pen25','g4','p18',2,'HOOK','00:49:36','no\r'),('pen26','g5','p2',2,'TRIP','00:06:20','no\r'),('pen27','g5','p3',2,'L-HIT','00:15:29','no\r'),('pen28','g5','p2',2,'TRIP','00:23:51','no\r'),('pen29','g5','p14',2,'CROSS','00:44:17','yes\r'),('pen3','g1','p6',2,'HOOK','00:51:31','yes\r'),('pen30','g5','p21',2,'ROUGH','00:51:07','no\r'),('pen31','g5','p21',2,'SLASH','00:59:33','yes\r'),('pen32','g6','p22',2,'SLASH','00:12:17','no\r'),('pen33','g6','p2',2,'TRIP','00:19:54','no\r'),('pen34','g6','p18',2,'SLASH','00:24:19','no\r'),('pen35','g6','p14',2,'CHE-H','00:32:35','no\r'),('pen36','g6','p14',10,'MISC','00:32:35','yes\r'),('pen37','g6','p14',2,'ROUGH','00:32:35','no\r'),('pen38','g6','p3',2,'SLASH','00:40:35','no\r'),('pen39','g6','p11',2,'L-HIT','00:41:14','no\r'),('pen4','g1','p11',2,'ROUGH','00:52:05','no\r'),('pen40','g6','p20',2,'HI-ST','00:42:47','no\r'),('pen41','g6','p17',2,'HOOK','00:43:31','no\r'),('pen42','g6','p3',2,'SLASH','00:45:43','no\r'),('pen43','g6','p3',25,'MATCH','00:53:15','no\r'),('pen44','g6','p18',2,'HOOK','01:02:53','no\r'),('pen45','g7','p23',2,'TOO-M','00:06:58','no\r'),('pen46','g7','p11',2,'INTRF','00:14:03','no\r'),('pen47','g7','p20',2,'SLASH','00:18:14','no\r'),('pen48','g7','p16',2,'SLASH','00:46:19','no\r'),('pen49','g7','p17',2,'TRIP','01:00:20','yes\r'),('pen5','g1','p3',2,'SLASH','00:54:05','no\r'),('pen50','g8','p14',2,'SLASH','00:02:03','no\r'),('pen51','g8','p8',2,'TRIP','00:14:14','no\r'),('pen52','g8','p13',2,'ROUGH','00:20:00','no\r'),('pen53','g8','p22',2,'FIGHT','00:29:08','no\r'),('pen54','g8','p22',2,'FIGHT','00:29:08','no\r'),('pen55','g8','p14',2,'HOOK','00:32:03','no\r'),('pen56','g8','p6',2,'HI-ST','00:32:15','no\r'),('pen57','g8','p23',2,'TOO-M','00:33:54','no\r'),('pen58','g8','p23',2,'DELAY','00:34:43','no\r'),('pen59','g8','p14',2,'ROUGH','00:47:03','no\r'),('pen6','g2','p8',2,'DELAY','00:17:00','no\r'),('pen60','g8','p14',2,'G-INTRF','00:57:06','no\r'),('pen61','g8','p14',2,'DIVING','00:59:58','no\r'),('pen62','g8','p14',10,'INCITE','00:59:58','no\r'),('pen63','g8','p14',10,'INCITE','00:59:58','no\r'),('pen64','g9','p8',2,'INTRF','00:11:21','yes\r'),('pen65','g9','p9',2,'HOOK','00:16:12','yes\r'),('pen66','g9','p21',2,'INTRF','00:20:00','no\r'),('pen67','g9','p9',2,'DELAY','00:20:12','no\r'),('pen68','g9','p13',2,'HOOK','00:29:28','yes\r'),('pen69','g9','p21',2,'CHE-H','00:34:07','no\r'),('pen7','g2','p7',2,'HOOK','00:34:21','no\r'),('pen70','g9','p21',10,'CHE-H','00:34:07','yes\r'),('pen71','g9','p2',2,'ELBOW','00:45:47','yes\r'),('pen72','g9','p4',2,'ABUSE','00:46:42','no\r'),('pen73','g10','p8',2,'CROSS','00:17:47','no\r'),('pen74','g10','p20',2,'TRIP','00:18:33','no\r'),('pen75','g10','p23',2,'TOO-M','00:19:57','no\r'),('pen76','g10','p17',2,'HOLD','00:27:05','yes\r'),('pen77','g10','p13',2,'SLASH','00:37:23','no\r'),('pen78','g10','p21',2,'HOOK','00:56:21','no\r'),('pen79','g11','p15',2,'SLASH','00:15:12','no\r'),('pen8','g2','p6',2,'HOLD','00:36:49','no\r'),('pen80','g11','p11',2,'SLASH','00:31:05','no\r'),('pen81','g12','p21',2,'HI-ST','00:15:42','yes\r'),('pen82','g12','p10',2,'SLASH','00:31:50','no\r'),('pen83','g12','p1',2,'TRIP','00:44:44','no\r'),('pen84','g12','p6',2,'INTRF','00:55:56','no\r'),('pen85','g12','p20',2,'TRIP','01:00:00','no\r'),('pen86','g13','p22',2,'CHE-B','00:12:32','no\r'),('pen87','g13','p22',10,'CHE-B','00:12:32','yes\r'),('pen88','g13','p11',2,'TRIP','00:20:28','no\r'),('pen89','g13','p21',2,'TRIP','00:27:51','yes\r'),('pen9','g2','p3',2,'HOLD','00:49:40','yes\r'),('pen90','g13','p14',2,'HOLD','00:48:13','yes\r'),('pen91','g13','p10',2,'KNEE','00:55:11','no\r'),('pen92','g13','p9',10,'ABUSE','01:00:00','no\r'),('pen93','g13','p9',20,'GA-MI','01:00:00','no\r'),('pen94','g14','p11',2,'CROSS','00:15:15','yes\r'),('pen95','g14','p20',2,'HOOK','00:21:44','yes\r'),('pen96','g14','p11',2,'TRIP','00:41:10','no\r'),('pen97','g14','p3',2,'SLASH','00:48:52','no\r'),('pen98','g15','p21',2,'HOOK','00:04:32','no\r'),('pen99','g15','p10',2,'CROSS','00:10:35','no\r');
/*!40000 ALTER TABLE `penalties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `players` (
  `player_id` varchar(50) NOT NULL,
  `fk_team_player` varchar(50) DEFAULT NULL,
  `nationality` varchar(50) DEFAULT NULL,
  `player_name` varchar(50) NOT NULL,
  `games_played` int DEFAULT NULL,
  `left_right` varchar(50) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `age` int DEFAULT NULL,
  `player_position` varchar(50) DEFAULT NULL,
  `height` int DEFAULT NULL,
  `weight` int DEFAULT NULL,
  `player_number1` varchar(50) DEFAULT NULL,
  `player_number2` varchar(50) DEFAULT NULL,
  `updated` date DEFAULT NULL,
  PRIMARY KEY (`player_id`),
  KEY `fk_team_player` (`fk_team_player`),
  CONSTRAINT `players_ibfk_1` FOREIGN KEY (`fk_team_player`) REFERENCES `teams` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES ('p1','t2','England','Adam Goss',19,'L','1995-02-10',25,'g',178,74,'84','\r','2020-07-13'),('p10','t2','England','James Galazzi',8,'L','1983-11-25',36,'c',183,96,'10','\r',NULL),('p11','t2','England','Joe Baird',19,'R','1980-05-19',40,'d',175,85,'15','\r',NULL),('p12','t2','England','Josh Ealey-Newman',5,'L','1998-08-20',21,'f',185,74,'63','\r',NULL),('p13','t2','England','Joshua Daniel Smith',13,'R','1998-01-21',22,'f',180,78,'27','\r',NULL),('p14','t2','England','Joshua Thomas Martin',19,'R','1995-07-27',24,'f',185,75,'88','\r',NULL),('p15','t2','England','Louis Colvin',18,'L','1999-05-31',21,'f',180,77,'81','\r',NULL),('p16','t2','England','Luke Jackson',16,'R','1999-04-23',21,'d',186,91,'4','\r',NULL),('p17','t2','Czech Republic','Robin Kovar',12,'R','1984-04-02',36,'c',186,87,'66','\r',NULL),('p18','t2','Czech Republic','Roman Malinik',19,'R','1990-02-06',30,'f',180,93,'34','\r',NULL),('p19','t2','England','Ryan Webb',19,'R','1994-04-14',26,'f',173,65,'18','\r',NULL),('p2','t2','England','Aidan Doughty',18,'L','1995-07-12',25,'f',188,91,'12','\r',NULL),('p20','t2','England','Stuart Mogg',19,'R','1994-08-01',25,'d',183,80,'94','\r',NULL),('p21','t2','England','William Stead',17,'R','1998-09-10',21,'f',185,73,'19','\r',NULL),('p22','t2','England','Zack Milton',19,'L','2001-05-10',19,'f',183,85,'29','\r',NULL),('p23','t2','N/A','bench',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\r',NULL,NULL),('p3','t2','England','Brendan Baird',15,'R','1996-01-21',24,'d',175,82,'75','\r',NULL),('p4','t2','England','Daniel Milton',17,'L','1993-07-28',26,'g',183,83,'42','\r',NULL),('p5','t2','Slovakia','Dominik Gabaj',3,'L','1992-12-18',27,'c',183,89,'87','23\r',NULL),('p6','t2','England','Edward James Knaggs',19,'L','1998-05-13',22,'d',180,75,'5','\r',NULL),('p7','t2','England','Gareth O\'Flaherty',11,'R','1990-01-18',30,'c',177,75,'4','78\r',NULL),('p8','t2','England','Harvey Stead',19,'R','1996-02-18',24,'d',181,85,'65','\r',NULL),('p9','t2','Russia','Ivan Antonov',6,'L','1997-05-12',23,'f',175,74,'24','\r',NULL);
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `set_updated` BEFORE UPDATE ON `players` FOR EACH ROW SET NEW.updated = CURDATE() */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `standings`
--

DROP TABLE IF EXISTS `standings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `standings` (
  `comp_day` varchar(50) NOT NULL,
  `comp_date` date NOT NULL,
  `t1` int DEFAULT NULL,
  `t2` int DEFAULT NULL,
  `t3` int DEFAULT NULL,
  `t4` int DEFAULT NULL,
  `t5` int DEFAULT NULL,
  `t6` int DEFAULT NULL,
  `t7` int DEFAULT NULL,
  `t8` int DEFAULT NULL,
  `t9` int DEFAULT NULL,
  `t10` int DEFAULT NULL,
  PRIMARY KEY (`comp_day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `standings`
--

LOCK TABLES `standings` WRITE;
/*!40000 ALTER TABLE `standings` DISABLE KEYS */;
INSERT INTO `standings` VALUES ('d1','2019-09-15',0,0,0,0,0,0,0,3,0,3),('d10','2019-10-18',0,0,0,0,0,0,0,0,3,0),('d11','2019-10-19',1,3,2,0,0,3,0,0,3,3),('d12','2019-10-20',3,0,2,1,3,1,0,0,0,2),('d13','2019-10-25',0,0,0,3,0,0,0,0,0,0),('d14','2019-10-26',0,2,0,0,0,3,0,0,3,1),('d15','2019-10-27',0,0,3,3,0,0,3,0,3,3),('d16','2019-11-02',2,0,0,0,1,3,0,0,3,3),('d17','2019-11-03',3,0,2,0,0,0,3,3,3,1),('d18','2019-11-09',2,0,3,0,3,0,0,3,3,1),('d19','2019-11-10',3,0,0,0,3,3,0,0,3,3),('d2','2019-09-21',3,3,3,0,0,0,0,0,0,0),('d20','2019-11-16',0,0,3,2,0,0,3,1,0,3),('d21','2019-11-17',2,0,0,0,0,3,1,3,0,3),('d22','2019-11-23',0,3,3,0,0,3,1,0,3,2),('d23','2019-11-24',0,0,3,0,0,3,3,0,3,0),('d24','2019-11-29',3,0,0,0,0,0,0,0,0,0),('d25','2019-11-30',3,3,1,0,2,0,0,0,0,3),('d3','2019-09-22',0,0,2,0,0,3,3,3,1,3),('d4','2019-09-28',3,0,3,0,3,0,0,0,3,3),('d5','2019-09-29',0,3,0,0,0,3,0,3,1,2),('d6','2019-10-05',3,0,0,0,0,0,3,3,3,0),('d7','2019-10-06',0,2,0,0,1,3,3,3,0,3),('d8','2019-10-12',3,0,0,0,0,3,0,0,3,3),('d9','2019-10-13',0,1,0,3,0,3,0,3,2,3);
/*!40000 ALTER TABLE `standings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teams` (
  `team_id` varchar(50) NOT NULL,
  `team_name` varchar(50) NOT NULL,
  `team_location` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teams`
--

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;
INSERT INTO `teams` VALUES ('t1','Basingstoke Bison','Basingstoke\r'),('t10','Telford Tigers','Telford\r'),('t2','Bracknell Bees','Bracknell\r'),('t3','Hull Pirates','Hull\r'),('t4','Leeds Chiefs','Leeds\r'),('t5','Milton Keynes Lightning','Milton Keynes\r'),('t6','Peterborough Phantoms','Peterborough\r'),('t7','Raiders','Romford\r'),('t8','Sheffield Steeldogs','Sheffield\r'),('t9','Swindon Wildcats','Swindon\r');
/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `view_detailed_information`
--

DROP TABLE IF EXISTS `view_detailed_information`;
/*!50001 DROP VIEW IF EXISTS `view_detailed_information`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_detailed_information` AS SELECT 
 1 AS `player_id`,
 1 AS `player_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_penalties`
--

DROP TABLE IF EXISTS `vw_penalties`;
/*!50001 DROP VIEW IF EXISTS `vw_penalties`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_penalties` AS SELECT 
 1 AS `player_id`,
 1 AS `player_position`,
 1 AS `COUNT(*)`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_detailed_information`
--

/*!50001 DROP VIEW IF EXISTS `view_detailed_information`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_detailed_information` AS select `p`.`player_id` AS `player_id`,`p`.`player_name` AS `player_name` from `players` `p` where (`p`.`nationality` = 'England') */
/*!50002 WITH CASCADED CHECK OPTION */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_penalties`
--

/*!50001 DROP VIEW IF EXISTS `vw_penalties`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_penalties` AS select `p`.`player_id` AS `player_id`,`p`.`player_position` AS `player_position`,count(0) AS `COUNT(*)` from (`players` `p` join `penalties` `pen` on((`p`.`player_id` = `pen`.`fk_penalty_player`))) group by `p`.`player_position` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-13 14:55:13
